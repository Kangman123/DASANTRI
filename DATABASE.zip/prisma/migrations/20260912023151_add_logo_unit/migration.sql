-- AlterTable
ALTER TABLE "Unit" ADD COLUMN     "logoUrl" TEXT;
